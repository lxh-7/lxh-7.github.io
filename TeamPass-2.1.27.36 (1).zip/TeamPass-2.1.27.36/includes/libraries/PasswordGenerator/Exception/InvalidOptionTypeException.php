<?php

namespace Hackzilla\PasswordGenerator\Exception;

class InvalidOptionTypeException extends \InvalidArgumentException
{
}
