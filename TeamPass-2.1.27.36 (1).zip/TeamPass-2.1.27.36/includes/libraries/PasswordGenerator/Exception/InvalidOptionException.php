<?php

namespace Hackzilla\PasswordGenerator\Exception;

class InvalidOptionException extends \InvalidArgumentException
{
}
