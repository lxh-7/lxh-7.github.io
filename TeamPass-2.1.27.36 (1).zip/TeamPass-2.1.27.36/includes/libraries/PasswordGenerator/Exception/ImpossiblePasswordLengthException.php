<?php

namespace Hackzilla\PasswordGenerator\Exception;

class ImpossiblePasswordLengthException extends \Exception
{

}
