<?php

namespace Hackzilla\PasswordGenerator\Exception;

class ImpossibleMinMaxLimitsException extends \Exception
{
}
