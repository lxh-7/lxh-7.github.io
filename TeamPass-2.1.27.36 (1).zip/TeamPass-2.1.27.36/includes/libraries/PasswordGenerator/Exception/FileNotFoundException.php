<?php

namespace Hackzilla\PasswordGenerator\Exception;

class FileNotFoundException extends \Exception
{
}
