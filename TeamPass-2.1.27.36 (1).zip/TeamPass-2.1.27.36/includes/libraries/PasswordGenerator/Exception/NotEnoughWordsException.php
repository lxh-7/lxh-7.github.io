<?php

namespace Hackzilla\PasswordGenerator\Exception;

class NotEnoughWordsException extends \Exception
{

}
