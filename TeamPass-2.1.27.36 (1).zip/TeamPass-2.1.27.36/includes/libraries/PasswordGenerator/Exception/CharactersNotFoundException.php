<?php

namespace Hackzilla\PasswordGenerator\Exception;

class CharactersNotFoundException extends \Exception
{
}
