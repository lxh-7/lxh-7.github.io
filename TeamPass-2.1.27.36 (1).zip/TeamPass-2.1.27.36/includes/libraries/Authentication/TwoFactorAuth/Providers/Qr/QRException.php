<?php

use Authentication\TwoFactorAuth\TwoFactorAuthException;

class QRException extends TwoFactorAuthException {}